<?php include("../resources/config.php");
session_destroy();
redirect("login.php");
?>