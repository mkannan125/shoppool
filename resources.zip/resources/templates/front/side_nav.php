<div class="col-md-3">
    <h1>Shoppool</h1>
    <br>
    <br>
    <br>
    <div class="list-group">

        <?php
            get_categories();
        ?>
    </div>
</div>